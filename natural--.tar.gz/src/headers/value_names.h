#ifndef _VNH
#define _VNH

static char *var_type_names[] = {
	"i64",
	"f64",
	"string",
	"array"
};

#endif
